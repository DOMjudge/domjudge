/*
 * This should give COMPILER-ERROR on the default problem 'hello',
 * since it includes a random extra file.
 *
 * @EXPECTED_RESULTS@: COMPILER-ERROR
 */

using System;

public class Hello
{
	public static void Main(string[] args)
	{
#if ONLINE_JUDGE
		Console.Write("Hello world!\n");
#else
		Console.Write("ONLINE_JUDGE not defined\n");
#endif
	}
}
