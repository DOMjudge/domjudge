# This should give COMPILER-ERROR on the default problem 'hello',
# since it includes a random extra file.
#
# @EXPECTED_RESULTS@: COMPILER-ERROR

if [ -z "$DOMJUDGE" -o -z "$ONLINE_JUDGE" ]; then
	echo "Variable DOMJUDGE and/or ONLINE_JUDGE not defined."
	exit 1
fi

echo "Hello world!"

exit 0
