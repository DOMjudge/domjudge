/*
 * This should give CORRECT on the default problem 'hello'.
 * It includes a random extra file, but this is filtered out by the
 * current ICPC WF compile scripts.
 *
 * @EXPECTED_RESULTS@: CORRECT
 */

#include <stdio.h>

int main()
{
	char hello[20] = "Hello world!";
	printf("%s\n",hello);
	return 0;
}
