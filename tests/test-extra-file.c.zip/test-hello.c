/*
 * This should give COMPILER-ERROR on the default problem 'hello',
 * since it includes a random extra file.
 *
 * @EXPECTED_RESULTS@: COMPILER-ERROR
 */

#include <stdio.h>

int main()
{
	char hello[20] = "Hello world!";
#ifdef ONLINE_JUDGE
	printf("%s\n",hello);
#else
	printf("ONLINE_JUDGE not defined\n");
#endif
	return 0;
}
