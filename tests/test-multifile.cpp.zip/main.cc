/*
 * This multifile submission should give CORRECT on the default problem 'hello'.
 *
 * @EXPECTED_RESULTS@: CORRECT
 */

#include "message.hpp"

int main()
{
	message msg;

	msg.print();

	return 0;
}
