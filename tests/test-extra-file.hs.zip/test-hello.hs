{-
 - This should give COMPILER-ERROR on the default problem 'hello',
 - since it includes a random extra file.
 -
 - @EXPECTED_RESULTS@: COMPILER-ERROR
 -}

import System.IO
main = do	putStr "Hello world!\n"
