# This should give COMPILER-ERROR on the default problem 'hello',
# since it includes a random extra file.
#
# @EXPECTED_RESULTS@: COMPILER-ERROR

echo "Hello world!"

exit 0
