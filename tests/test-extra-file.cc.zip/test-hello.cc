/*
 * This should give COMPILER-ERROR on the default problem 'hello',
 * since it includes a random extra file.
 *
 * @EXPECTED_RESULTS@: COMPILER-ERROR
 */

#include <iostream>
#include <string>

using namespace std;

int main()
{
	string hello("Hello world!");
	cout << hello << endl;
	return 0;
}
