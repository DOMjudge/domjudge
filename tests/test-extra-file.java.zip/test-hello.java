/*
 * This should give COMPILER-ERROR on the default problem 'hello',
 * since it includes a random extra file.
 *
 * @EXPECTED_RESULTS@: COMPILER-ERROR
 */

import java.io.*;

class Main {
    public static void main(String[] args) throws Exception {
		System.out.print("Hello world!\n");
    }
}
