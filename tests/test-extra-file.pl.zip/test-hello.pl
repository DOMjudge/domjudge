# This should give COMPILER-ERROR on the default problem 'hello',
# since it includes a random extra file.
#
# @EXPECTED_RESULTS@: COMPILER-ERROR

print "Hello world!\n";

exit;
