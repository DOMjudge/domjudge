# This should give COMPILER-ERROR on the default problem 'hello',
# since it includes a random extra file.
#
# @EXPECTED_RESULTS@: COMPILER-ERROR

if ENV['DOMJUDGE'] != '' then
  puts "Hello world!"
else
  puts "DOMJUDGE not defined"
  exit(1)
end
