/*
 * This should give CORRECT on the default problem 'hello'.
 * Even though this program is valid, the accompanying file is not a
 * proper C-header file and thus should lead to a compiler error,
 * either failing on trying to interpret it as C-header file, or
 * disallowing random extra files in a submission.
 * However, the current ICPC WF compile scripts filter out non-source
 * files, so this should work fine.
 *
 * @EXPECTED_RESULTS@: CORRECT
 */

#include <stdio.h>

int main()
{
	char hello[20] = "Hello world!";
	printf("%s\n",hello);
	return 0;
}
