/*
 * This should give COMPILER-ERROR on the default problem 'hello'.
 * Even though this program is valid, the accompanying file is not a
 * proper C-header file and thus should lead to a compiler error,
 * either failing on trying to interpret it as C-header file, or
 * disallowing random extra files in a submission.
 *
 * @EXPECTED_RESULTS@: COMPILER-ERROR
 */

#include <stdio.h>

int main()
{
	char hello[20] = "Hello world!";
#ifdef ONLINE_JUDGE
	printf("%s\n",hello);
#else
	printf("ONLINE_JUDGE not defined\n");
#endif
	return 0;
}
